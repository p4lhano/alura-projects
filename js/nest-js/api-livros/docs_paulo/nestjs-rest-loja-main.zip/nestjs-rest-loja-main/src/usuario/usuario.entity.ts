export class UsuarioEntity {
  id: string;
  nome: string;
  email: string;
  senha: string;
}
