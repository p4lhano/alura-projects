const Services = require('./Services')

class MatriculasServices extends Services {
  constructor(){
    super('Matriculas')
  }
}

module.exports = MatriculasServices